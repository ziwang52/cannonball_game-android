package com.example.graphicsexample

import android.app.AlertDialog
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.graphics.*
import android.graphics.drawable.Drawable
import android.health.connect.datatypes.units.Velocity
import android.util.Log
import android.view.MotionEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

import java.util.Timer
import kotlin.math.cos
import kotlin.math.sin

class CannonBall(private val initialX: Float, private val initialY: Float, private val initialVelocity: Float, private val initialAngle: Float) {
  private val GRAVITY = 9.8f
  private val pixelsPerMeter = 1.0f // Adjust this based on your scale factor
  private var x: Float = initialX
  private var y: Float = initialY

  private var time1 = 0.5f
  val initialAngleRadians = Math.toRadians(initialAngle.toDouble()).toFloat()

  fun updatePosition(timeElapsed: Float) {
    // Update x and y based on the physics equations
    x = (initialVelocity * cos(initialAngleRadians) * time1) + initialX
    y = (
            (-initialVelocity * sin(initialAngleRadians) * time1 +
                    0.5 * GRAVITY * time1 * time1) + initialY
            ).toFloat()
    time1++
  }

  fun getPosition(): Pair<Float, Float> {
    return Pair(x, y)
  }
}
class MyView :  View
{
  companion object
  {
    private var instance : MyView? = null
    public fun getInstance() : MyView
    {
      return instance!!
    }
  }


  private var targets = ArrayList<Drawable>() //Targets

  private var rectCoords : Rect = Rect(0,0,0,0)
  private var circleCoords : RectF = RectF(0.0f,0.0f,0.0f,0.0f)
   private var shotCount = 0
  private var score = 0
  var cannonball_x =0.0f
  var cannonball_y =0.0f
  private val paint = Paint(Paint.ANTI_ALIAS_FLAG)  //One per widget
    private var barrelAngle: Float = 0f
  private var cannonVelocity: Float = 0f
  private var cannonBall: CannonBall? = null

  private fun showGameOverDialog() {
    var shots =MainActivity.getInstance().shotcount
    val alertDialogBuilder = AlertDialog.Builder(context)
    alertDialogBuilder.setTitle("Game Over")
    alertDialogBuilder.setMessage("Shots: $shots\nScore: $score")

    alertDialogBuilder.setPositiveButton("OK") { dialog, which ->
      // Reset the game when OK is clicked
      resetGame()
    }

    val alertDialog = alertDialogBuilder.create()
    alertDialog.show()
  }
  // Add a function to update the barrel angle
  fun setBarrelAngle(angle: Float) {
    this.barrelAngle = angle
    invalidate()  // Invalidate the view to trigger onDraw
  }
  fun setcannonVelocity(velocity: Float) {
    this.cannonVelocity = velocity

  }


  constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
  {
    rectCoords.set(80, 100,250, 250)

    circleCoords.set(300.0f,300.0f,450.0f,450.0f)
    instance = this
  }


  fun updateCannonBallPosition(time: Float) {
    if ( cannonBall == null) {
      cannonBall = CannonBall(cannonball_x, cannonball_y, cannonVelocity, barrelAngle)
    }


      val timeInterval = 0.05f
      cannonBall?.updatePosition(timeInterval)

      val cannonBallPosition = cannonBall?.getPosition()

      if (cannonBallPosition != null) {
        // Check if the cannonball hits any target
        val targetsToRemove = mutableListOf<Drawable>()
        for (drawable in targets) {
          val bounds = drawable.bounds
          if (cannonBallPosition.first >= bounds.left &&
            cannonBallPosition.first <= bounds.right &&
            cannonBallPosition.second >= bounds.top &&
            cannonBallPosition.second <= bounds.bottom
          ) {
            targetsToRemove.add(drawable)
            score++
            val scoreTextView = MainActivity.getInstance().findViewById<TextView>(R.id.score)
            scoreTextView.text = score.toString()

          }
        }

        // Remove the targets that need to be removed
        for (targetToRemove in targetsToRemove) {
          targets.remove(targetToRemove)
        }

        if (targets.isEmpty()) {
          // If all targets are removed, end the game
          showGameOverDialog()
          resetGame()
        }
      }

  //  cannonBall == null
      invalidate()

  }
  fun resetCannonBall() {
    cannonBall = null
  }

  private fun createTargets() {
    targets.clear()
    // Create 7x7 grid of targets
    val targetWidth = 100
    val targetHeight = 100
    val startX = 0.5f * width
    val startY = 0.1f * height

    for (i in 0 until 7) {
      for (j in 0 until 7) {
        val x = startX + i * targetWidth
        val y = startY + j * targetHeight

        var imageView = ImageView(MainActivity.getInstance())
        imageView.setImageResource(R.drawable.untouched)
        var drawable = imageView.getDrawable()
        drawable.setBounds(x.toInt(), y.toInt(), (x + 100).toInt(), (y + 100).toInt())
        targets.add(drawable)
      }
    }
  }
  private fun resetGame() {
    MainActivity.getInstance().shotcount= 0
    val score1 = MainActivity.getInstance().findViewById<TextView>(R.id.score)
    score1.text = "0"
    val shot1 = MainActivity.getInstance().findViewById<TextView>(R.id.shots)
    shot1.text = "0"
    score = 0
    shotCount=0
    targets.clear()
    createTargets() // Create new targets
    invalidate()
  }
  override fun onDraw(canvas: Canvas)
  {
    super.onDraw(canvas)
    // Load cannon base image
    val cannonBaseBitmap = BitmapFactory.decodeResource(resources, R.drawable.cannon_base)
    val barrelLength = 70f  // Adjust as needed

    // Draw bottom boundary
    paint.color = Color.parseColor("#7F7F00")
    canvas.drawRect(0f, 0.9f * height, width.toFloat(), height.toFloat(), paint)

    // Draw cannon's base
    val baseTop = 0.9f * height - cannonBaseBitmap.height
    canvas.drawBitmap(cannonBaseBitmap, 0f, baseTop, paint)

    // Calculate the position of the cannon's barrel start based on the cannon's base
    val barrelStartX = 0.5f * cannonBaseBitmap.width
    val barrelStartY = baseTop

    // Calculate the endpoint of the barrel based on angle and length
    val barrelEndX = barrelStartX + barrelLength * cos(Math.toRadians(barrelAngle.toDouble())).toFloat()
    val barrelEndY = barrelStartY - barrelLength * sin(Math.toRadians(barrelAngle.toDouble())).toFloat()
    cannonball_x =barrelEndX
    cannonball_y=barrelEndY

    // Draw the barrel
    val path = Path()
    path.moveTo(barrelStartX, barrelStartY)
    path.lineTo(barrelEndX, barrelEndY)
    val paint = Paint()
    paint.color = Color.BLACK
    paint.strokeWidth = 20f  // Adjust as needed
    paint.style = Paint.Style.STROKE
    // Draw the path
    canvas.drawPath(path, paint)
    // Draw the cannonball at the end of the barrel
    val cannonBallBitmap = BitmapFactory.decodeResource(resources, R.drawable.cannon_ball)
    val ballWidth = cannonBallBitmap.width * 0.3f  // Adjust the scaling factor as needed
    val ballHeight = cannonBallBitmap.height * 0.3f  // Adjust the scaling factor as needed

    // Use the cannonBall instance to get its position
    val cannonBallPosition = cannonBall?.getPosition()

    // Check if cannonBallPosition is not null before drawing
    if (cannonBallPosition != null) {
      val ballLeft = cannonBallPosition.first - ballWidth
      val ballTop = cannonBallPosition.second - ballHeight
      canvas.drawBitmap(
        cannonBallBitmap,
        null,
        RectF(ballLeft + 30f, ballTop + 10f, cannonBallPosition.first + 30f, cannonBallPosition.second + 30f),
        paint
      )
    }


    var counter : Int = 0

    // Check if the cannonball hits any target
    val targetsToRemove = mutableListOf<Drawable>()
    val cannonBallPosition1 = cannonBall?.getPosition()
    if (cannonBallPosition1 != null) {
      for (drawable in targets) {
        val bounds = drawable.bounds
        if (cannonBallPosition1.first >= bounds.left &&
          cannonBallPosition1.first <= bounds.right &&
          cannonBallPosition1.second >= bounds.top &&
          cannonBallPosition1.second <= bounds.bottom
        ) {
          // Add the target to the list of targets to be removed
          targetsToRemove.add(drawable)
          counter++
          val score = MainActivity.getInstance().findViewById<TextView>(R.id.score)
          score.text = counter.toString()
        }
      }
    }

// Remove the targets that need to be removed
    for (targetToRemove in targetsToRemove) {
      targets.remove(targetToRemove)
      // Increment the score

    }

// Draw the targets normally
    for (i in 0 until targets.size) {
      var drawable = targets[i]
      drawable.draw(canvas)
    }
  }
  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int)
  {
    super.onSizeChanged(w, h, oldw, oldh)
    var width = this.getWidth()
    var height = this.getHeight()
    val startX = 0.5f * width
    val startY = 0.1f * height
// Create 7x7 grid of targets
    val targetWidth = 100  // Adjust as needed
    val targetHeight = 100  // Adjust as needed
    //Run only once per class
    for (i in 0 until 7)
    {

      for (j in 0 until 7) {
        val x = startX + i * targetWidth
        val y = startY + j * targetHeight

        var imageView = ImageView(MainActivity.getInstance())
        imageView.setImageResource(R.drawable.untouched)
        var drawable = imageView.getDrawable()
        drawable.setBounds(x.toInt(), y.toInt(), (x+100).toInt(), (y+100).toInt()) //Sets the dimensions
        targets.add(drawable)  //stores away the image
      }

      }





  }

  inner  class Handler1 : View.OnClickListener
  {
    private var counter : Int = 0
    private var total : Int = targets.size
    override fun onClick(v: View?)
    {
      if (counter < total)
      {
        //Get the drawable
        targets.removeAt(0)

        MyView.getInstance().invalidate()
        counter++
      }
    }
  }




}