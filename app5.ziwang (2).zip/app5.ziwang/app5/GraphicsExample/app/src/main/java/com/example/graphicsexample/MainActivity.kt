package com.example.graphicsexample

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory.Companion.instance
import java.util.Timer
import java.util.TimerTask

class HelperThread : Runnable
{
  override fun run()
  {
    MainActivity.getInstance().update()

     }
  }



class TimerObject : TimerTask()
{
  override fun run()
  {
    var helper = HelperThread()

    MainActivity.getInstance().runOnUiThread(helper)
  }
}


class MainActivity : AppCompatActivity() {

  var shotcount = 0
  private var timer = Timer()
  private var timerStarted = false



  public fun fire() {

    val myView = findViewById<MyView>(R.id.myView)
    val angleSeekBar = findViewById<SeekBar>(R.id.angleSeekBar)
    val velocitySeekBar = findViewById<SeekBar>(R.id.velocitySeekBar)

    // Get the current progress of angle and velocity SeekBars
    val angleProgress = angleSeekBar.progress.toFloat()
    val velocityProgress = velocitySeekBar.progress.toFloat()

    // Set the angle and velocity in MyView
    myView.setBarrelAngle(angleProgress)
    myView.setcannonVelocity(velocityProgress)

    // Start the timer if not already started
    if (!timerStarted) {
      val timerTask = TimerObject()
      timer.schedule(timerTask, 0, 200)
      timerStarted = true
    }
    // Reset the cannonball
    myView.resetCannonBall()

    // Invalidate the MyView to trigger onDraw
    MyView.getInstance().invalidate()

  }
  companion object {
    private var instance: MainActivity? = null
    public fun getInstance(): MainActivity {
      return instance!!
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    instance = this

    setContentView(R.layout.activity_main)
    val angleSeekBar = findViewById<SeekBar>(R.id.angleSeekBar)
    val velocitySeekBar = findViewById<SeekBar>(R.id.velocitySeekBar)
    val myView = findViewById<MyView>(R.id.myView)



    var handler = Handler()


    val angleSeekBar1 = findViewById<SeekBar>(R.id.angleSeekBar)
    angleSeekBar1.setOnSeekBarChangeListener(handler)

    val velocitySeekBar1 = findViewById<SeekBar>(R.id.velocitySeekBar)
    velocitySeekBar1.setOnSeekBarChangeListener(handler)

    val fireButton = findViewById<Button>(R.id.fire)
    fireButton.setOnClickListener (handler)

    var timerTask = TimerObject()
    //timer.schedule(timerTask,0,25)
    angleSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

      override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {

        when (seekBar?.id) {
          R.id.angleSeekBar -> {
            val angleTextView = MainActivity.getInstance().findViewById<TextView>(R.id.angel)
            var text = progress.toString()
            angleTextView.setText(text)
            myView.setBarrelAngle(progress.toFloat())

            // Invalidate the view to trigger onDraw

          }

          R.id.velocitySeekBar -> {
            val velocityTextView = MainActivity.getInstance().findViewById<TextView>(R.id.velocity)
            var text1 = progress.toString()
            velocityTextView.setText(text1)
            myView.setcannonVelocity(progress.toFloat())

          }
        }
        // Update the angle in MyView


      }

      override fun onStartTrackingTouch(seekBar: SeekBar?) {}
      override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    })
  }


  public fun update() {
    var myView = findViewById<MyView>(R.id.myView)
    var ball = findViewById<ImageView>(R.id.ball)
    if (myView.getWidth() > 1)
    {
      myView.updateCannonBallPosition(0.01f)
      myView.invalidate()
    }
   //
  }


  inner class Handler : View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
      when (seekBar?.id) {

        R.id.velocitySeekBar -> {
          val velocityTextView = MainActivity.getInstance().findViewById<TextView>(R.id.velocity)
          var text1 = progress.toString()
          velocityTextView.setText(text1)

        }
      }
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {
      // Handle the start of tracking if needed
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?) {
      // Handle the end of tracking if needed
    }

    override fun onClick(v: View?) {
      var text = (v as Button).getText()
      if (text == "FIRE")
        {
          // Update the shot count
          shotcount++
          val shot = findViewById<TextView>(R.id.shots)
          val text = shotcount.toString()
          shot.text = text

          fire()
        update()

      }
    }
  }
}

